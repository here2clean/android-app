package com.dijouxdamien.here2cleanapp;

import java.util.List;

public class HttpEventDAO implements EventDAO {
    @Override
    public List<Event> getAllEvents() {
        return null;
    }

    @Override
    public Event getEventById(int id) {
        return null;
    }
}
