package com.dijouxdamien.here2cleanapp;

public interface VolunteerDAO {
    public  Volunteer getVolunteerById(int id);

}
