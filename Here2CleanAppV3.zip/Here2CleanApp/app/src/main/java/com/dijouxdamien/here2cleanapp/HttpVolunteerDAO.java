package com.dijouxdamien.here2cleanapp;

public class HttpVolunteerDAO implements VolunteerDAO {
    @Override
    public Volunteer getVolunteerById(int id) {
        return null;
    }
}
