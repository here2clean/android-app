package com.dijouxdamien.here2cleanapp;

public class Constants {
    public static final  int RC_SIGN_IN = 1000;
}
