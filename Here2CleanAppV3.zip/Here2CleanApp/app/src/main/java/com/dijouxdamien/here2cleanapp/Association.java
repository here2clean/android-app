package com.dijouxdamien.here2cleanapp;

public class Association {
    private String name;
    private long rna;
    private String email;
}


